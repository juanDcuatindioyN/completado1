/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package serverjuegosrmi;

import Interface.RMIDAO;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import javax.management.remote.rmi.RMIServer;


/**
 *
 * @author dlcaj
 */
public class ServerJuegosRMI extends UnicastRemoteObject implements RMIDAO{
    public ServerJuegosRMI() throws RemoteException{
        super();


    /**
     * @param args the command line arguments
     */
    public static void main(String [] args){
        try{Registry registro = LocateRegistry.createRegistry(7777);
        registro.rebind("RemotoRMI",new ServerJuegosRMI ());
            System.out.println("El Servidor Esta Activo");
        }catch(RemoteException ex){
            System.out.print(ex.getMessage());
        }    
    }


    @Override
    public boolean VerificarUsuarios(String usuario, String contrasenia) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getUsuario() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean CambiarContrasenia(String contrasenia) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
           
}
